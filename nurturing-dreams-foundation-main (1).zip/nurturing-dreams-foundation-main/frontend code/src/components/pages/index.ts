export { default as MainHome } from "./MainHome";
export { default as Login } from "./Login";
export { default as Register } from "./registration/Register";
export { default as Reset } from "./resetPWD/ResetPassword";
export { default as ForgotPWD } from "./ForgotPWD";
export { default as ContactUs } from "./ContactUs";
